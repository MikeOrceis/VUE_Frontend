  
<template>
  <v-card>
    <v-tabs
      background-color="green"
      center-active
      dark
    >
      <v-tab>One</v-tab>
      <v-tab>Two</v-tab>

    </v-tabs>
  </v-card>
</template>