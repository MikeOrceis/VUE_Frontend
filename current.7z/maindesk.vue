<template>
  <div>
    <v-data-table
      :headers="headers"
      :items="case"
      item-key="name"
      class="elevation-1"
      :search="search"
      :loading="loading"
      :custom-filter="filterOnlyCapsText"
    >
      <template v-slot:top>
        <v-text-field
          v-model="search"
          label="Search (UPPER CASE ONLY)"
          class="mx-4"
        ></v-text-field>
      </template>
      <template v-slot:body.append>
        <tr>
          <td></td>
          <td>

          </td>
          <td colspan="4"></td>
        </tr>
      </template>
    </v-data-table>
  </div>
</template>


<script>
import axios from 'axios';
  export default {
    data () {
      return {
        search: '',
        case: [],
        loading: true,
        headers: [
          {
            text: 'Nachname',
            align: 'start',
            sortable: false,
            value: 'nachname',
          },
          { text: 'Vorname', value: 'Vorname' },
          { text: 'Department', value: 'department' },
          { text: 'Costcenter', value: 'costcenter' },
          { text: 'Maschine', value: 'maschine' },
          { text: 'Beschreibung', value: 'description'},
          { text: 'Geoeffnet', sortable: true ,value: 'started'},
        ],
      };
    },
    watch: {
      options: {
        handler() {
          this.readDataFromAPI();
        },
      },
      deep: true
    },
    methods: {
      filterOnlyCapsText (value, search) {
        return value != null &&
          search != null &&
          typeof value === 'string' &&
          value.toString().toLocaleUpperCase().indexOf(search) !== -1
      },
      readDataFromAPI(){
         this.loading = true;
               axios
        .get(
          "http://localhost:3000/case?state=prio"
        )
        .then((response) => {
          this.loading = false;
          this.case = response.data.data;
        });

      }
    },
    mounted () {
      this.readDataFromAPI
    },
  
  }
</script>